from django.db import models
from django.forms import ModelForm;
# Create your models here.

class Story(models.Model):
    stories = models.CharField(max_length=1024)


class storyform(ModelForm):
    class Meta:
        model = Story
        fields = ['stories']

