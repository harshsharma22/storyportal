from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect,HttpResponse
from django.template import RequestContext
from blog.models import Story
from blog.models import storyform


# Create your views here.

def detail(request,id):
    stry= Story.objects.get(pk = id)
    return render_to_response('storydetails.html' , {'story': stry})

def index1(request):
    return HttpResponse('<html><body><h1>harsh</h!></body></html>')

def home(request):

    story = Story.objects.all()
    return render(request, 'show.html', {'story': story})


def create(request):
    if request.method == "GET":
        form = storyform()
        return render(request, 'create.html', {'form': form})
    elif request.method == "POST":
        form = storyform(request.POST)
        form.save()
        return HttpResponseRedirect('/home')




